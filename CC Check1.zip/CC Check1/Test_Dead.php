<?php
//Script Author: ᴛɪᴋᴏʟ4ʟɪғᴇ https://t.me/Tikol4Life

echo '<div class="dead" style="display:none;"><span class="badge badge-danger">DEAD</span> <span style="color: #FFFFFF"> Tikol4Life Test Mode</span></div>';
?>
