<?php
//Script Author: ᴛɪᴋᴏʟ4ʟɪғᴇ https://t.me/Tikol4Life

echo '<div class="live_ccn" style="display:none;"><span class="badge badge-warning">CCN LIVE</span> <span style="color: #FFFFFF"> Tikol4Life Test Mode</span></div>';
?>
